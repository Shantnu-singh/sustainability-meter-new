<?php
/**
 * Plugin Name: Sustainability Meter Quiz
 * Description: A plugin for an environmental awareness quiz.
 * Version: 1.0
 * Author: Your Name
 */

// Enqueue the necessary scripts and styles
function sustainability_meter_enqueue_scripts() {
    wp_enqueue_style('sustainability-meter-style', plugin_dir_url(__FILE__) . 'styles.css');
    wp_enqueue_script('sustainability-meter-script', plugin_dir_url(__FILE__) . 'script.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'sustainability_meter_enqueue_scripts');

// Shortcode function to display the quiz
function sustainability_meter_display_quiz() {
    ob_start();
    ?>
    <div class="headings">
      <h1>Sustainability Meter</h1>
    </div>
    <div class="container">
      <div id="ageSection">
        <h2>Name: <input type="text" id="name" /></h2>
        <h2>Age: <input type="number" id="ageInput" min="8" max="99" /></h2>
        <h2>Email: <input type="email" id="emailId" /></h2>
        <button onclick="showQuestion()">Start Quiz</button>
      </div>
      <div id="quizSection" style="display: none;">
        <div id="questionNumber"></div>
        <div id="question"></div>
        <div id="desc"></div>
        <input type="range" id="slider" min="0" max="5" value="0" />
        <div id="sliderValue">Never</div>
        <button onclick="submitAnswer()">Next</button>
      </div>
      <div id="resultSection" style="display: none;">
        <h2>Your score: <span id="result"></span></h2>
        <!-- <img class="imgw" src="<?php echo plugin_dir_url(__FILE__) . 'images/mett.png'; ?>" alt="Meter" /> -->
        <img id="resultImage" src="" alt="Result" />
        <button id="re" onclick="restartQuiz()">Restart Quiz</button>
      </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('sustainability_meter_quiz', 'sustainability_meter_display_quiz');
